package com.chuanglan.Sendrecord;

import com.chuanglan.Util.HttpUtil;

import java.util.HashMap;
import java.util.Map;

/*sendDay：post方式提交请求，不支持JSON请求*/
public class SendMonth {

    public static void main(String[] args) throws Exception {
        /*请求地址*/
        String url="https://zz.253.com/apis/sendrecord/sendMonth";

        Map<String, Object> map = new HashMap();
        /*必填参数*/
        map.put("appid", 49);//需要设置的产品id（appid）

        /*选填参数*/
        map.put("sub_id","");//子账号id
        map.put("start_date", "");//格式：xxxx-xx-xx，默认当天
        map.put("end_date","");//格式：xxxx-xx-xx，默认当天

        String result = HttpUtil.post(url, map);
        System.out.println("响应参数 ："+result);
    }

}
