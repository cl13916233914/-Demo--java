package com.chuanglan.Template;

import java.util.HashMap;
import java.util.Map;

import com.chuanglan.Util.HttpUtil;
import com.chuanglan.Util.MD5;

/*模板列表查询：采用post方式提交请求*/
public class TemplateList {

	public static void main(String[] args) throws Exception {
		/*请求地址*/
		String url="https://zz.253.com/apis/template/list";

		Map<String, Object> map = new HashMap();
		/*必填参数*/
		map.put("appid", 49);//需要设置的产品id，由创蓝提供
		/*选填参数*/
		map.put("sub_id", "");//子账号id
		map.put("start", "");//偏移量，默认为0
		map.put("length","");//查询的长度，默认为10，最大值为100

		String result = HttpUtil.post(url, map);
		System.out.println("响应参数 ： "+result);

	}
}
