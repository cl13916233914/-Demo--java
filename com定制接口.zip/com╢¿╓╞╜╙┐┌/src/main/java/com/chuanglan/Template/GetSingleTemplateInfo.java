package com.chuanglan.Template;

import com.chuanglan.Util.HttpUtil;
import com.chuanglan.Util.MD5;

import java.util.HashMap;
import java.util.Map;

/*模板ID单个查询：采用post方式提交请求*/
public class GetSingleTemplateInfo {

    public static void main(String[] args) throws Exception {
        /*请求地址*/
        String url="https://zz.253.com/apis/template/getSingleTemplateInfo";

        Map<String, Object> map = new HashMap();
        /*必填参数*/
        map.put("appid", 49);//需要设置的产品id（appid）
        map.put("id", "");//模板id。 例：209665
        /*选填参数*/
        map.put("sub_id", "");//子账号id

        String result = HttpUtil.post(url, map);
        System.out.println("响应参数 ："+result);
    }
}
