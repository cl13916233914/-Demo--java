package com.chuanglan.Template;

import com.chuanglan.Util.HttpUtil;

import java.util.HashMap;
import java.util.Map;

/*模板添加：采用post方式提交请求*/
public class TemplateAdd {

    public static void main(String[] args) throws Exception {
        /*请求地址*/
        String url="https://zz.253.com/apis/template/add";

        Map<String, Object> map = new HashMap();
        /*必填参数*/
        map.put("appid", 49);//需要设置的产品id（appid）
        map.put("content", "【253云通讯】欢迎"); //模板内容

        /*选填参数*/
        map.put("sign", "");//签名 [新注：新建模板不需要传此参数]
        map.put("remark","");//备注内容
        map.put("unsubscribe","");//后缀，适用于营销短信unsubscribe：对应后缀退订回复TD、退订回复T....
        map.put("sub_id","");//子账号id

        String result = HttpUtil.post(url, map);
        System.out.println("响应参数 ："+result);
    }

}
