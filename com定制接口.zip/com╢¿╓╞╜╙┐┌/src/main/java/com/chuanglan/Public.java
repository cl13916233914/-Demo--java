package com.chuanglan;

import com.chuanglan.Util.MD5;

public class Public {

    //用户名
    public final static String username = "13757936270";
    //密码
    public final static String password = "lrene120222";
    //时间戳
    public final static Long timestamp = System.currentTimeMillis()/1000;
    //签名
    public final static String signature = MD5.encode(username+password+timestamp);

}
