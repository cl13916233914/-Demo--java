package com.chuanglan.Signature;

import com.chuanglan.Util.HttpUtil;

import java.util.HashMap;
import java.util.Map;

/*签名列表查询：采用post方式提交请求*/
public class SignatureList {

    public static void main(String[] args) throws Exception {
        /*请求地址*/
        String url="https://zz.253.com/apis/template/list";

        Map<String, Object> map = new HashMap();
        /*必填参数*/
        map.put("appid", 49);//需要设置的产品id，由创蓝提供
        /*选填参数*/
        map.put("start", "");//偏移量，默认为0
        map.put("length","");//查询的长度，默认为10，最大值为100

        String result = HttpUtil.post(url, map);
        System.out.println("响应参数 ： "+result);

    }

}