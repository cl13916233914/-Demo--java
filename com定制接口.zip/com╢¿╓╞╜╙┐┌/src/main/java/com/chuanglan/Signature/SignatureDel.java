package com.chuanglan.Signature;

import com.chuanglan.Util.HttpUtil;

import java.util.HashMap;
import java.util.Map;

/*签名删除：采用post方式提交请求*/
public class SignatureDel {

    public static void main(String[] args) throws Exception {
        /*请求地址*/
        String url="https://zz.253.com/apis/signature/del";

        Map<String, Object> map = new HashMap();
        /*必填参数*/
        map.put("appid", 49);//需要设置的产品id（appid）
        map.put("id", "");//签名id。 例：176689
        /*选填参数*/

        String result = HttpUtil.post(url, map);
        System.out.println("响应参数 ："+result);
    }
}
