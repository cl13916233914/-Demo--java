package com.chuanglan.Signature;

import com.chuanglan.Util.HttpUtil;

import java.util.HashMap;
import java.util.Map;

/*签名添加：采用post方式提交请求*/
public class SignatureAdd {

    public static void main(String[] args) throws Exception {
        /*请求地址*/
        String url="https://zz.253.com/apis/signature/signatureAdd";

        Map<String, Object> map = new HashMap();
        /*必填参数*/
        map.put("appid", 49);//需要设置的产品id（appid）
        map.put("signature_name", "【253云通讯6】"); //签名，比如“253云通讯

        /*选填参数*/
        map.put("remind_type", "");//是否需要审核提醒，1需要，0不需要
        map.put("remind_phone","");//提醒手机，remind_type为1的情况下此值必须
        map.put("signature_scene_type","1");
        /*
        * 应用场景，默认为1 备注：
        *
        * 1 签名为公司
        * 2 签名为媒体，报社，学校，医院，机关事业单位名称
        * 3 签名为自己产品名/网站名/APP名称等
        * 4 签名为他人产品名/网站名等
        *
        * */

        String result = HttpUtil.post(url, map);
        System.out.println("响应参数 ："+result);

    }
}
