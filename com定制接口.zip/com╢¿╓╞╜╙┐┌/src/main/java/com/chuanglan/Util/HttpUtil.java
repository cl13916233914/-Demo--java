package com.chuanglan.Util;

import org.apache.http.HttpEntity;
import org.apache.http.NameValuePair;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import com.chuanglan.Public;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class HttpUtil {
    /**
     * http get请求
     *
     * @param url
     *           请求地址
     * @param params
     *            请求参数
     * @return
     */
    public static String get(String url, Map<String, Object> params) {
        CloseableHttpResponse response = null;
        CloseableHttpClient httpClient = null;
        try {
            if (params != null && !params.isEmpty()) {
                url = url + "?";
                for (Iterator<String> iterator = params.keySet().iterator(); iterator.hasNext();) {
                    String key = iterator.next();
                    String temp = key + "=" + params.get(key) + "&";
                    url = url + temp;
                }
                url = url.substring(0, url.length() - 1);
            }
            HttpGet httpGet = new HttpGet(url);
            httpClient = HttpClients.createDefault();
            RequestConfig config = RequestConfig.custom().setConnectionRequestTimeout(10000).setConnectTimeout(10000)
                    .setSocketTimeout(10000).build();
            httpGet.setConfig(config);
            response = httpClient.execute(httpGet);
            HttpEntity entity = response.getEntity();
            if (entity != null) {
                return EntityUtils.toString(entity, "utf-8");
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            try {
                response.close();
                httpClient.close();
            } catch (IOException e) {
            }
        }
        return "";
    }

    /**
     * http post请求
     *
     * @param url
     *            请求地址
     * @param params
     *            请求参数
     * @return
     */
    public static String post(String url, Map<String, Object> params) {
        params.put("username", Public.username);
        params.put("timestamp", Public.timestamp);
        params.put("signature", Public.signature);
        CloseableHttpResponse response = null;
        CloseableHttpClient httpClient = null;
        try {
            HttpPost httpPost = new HttpPost(url);
            List<BasicNameValuePair> parameters = new ArrayList<BasicNameValuePair>();
            for (Iterator<String> iterator = params.keySet().iterator(); iterator.hasNext();) {
                String key = iterator.next();
                parameters.add(new BasicNameValuePair(key, params.get(key).toString()));
            }
            UrlEncodedFormEntity uefEntity = new UrlEncodedFormEntity(parameters, "utf-8");
            httpPost.setEntity(uefEntity);
            RequestConfig config = RequestConfig.custom().setConnectionRequestTimeout(10000).setConnectTimeout(10000)
                    .setSocketTimeout(10000).build();
            httpPost.setConfig(config);
            httpClient = HttpClients.createDefault();
            response = httpClient.execute(httpPost);
            HttpEntity entity = response.getEntity();
            if (entity != null) {
                return EntityUtils.toString(entity, "utf-8");
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            try {
                response.close();
                httpClient.close();
            } catch (IOException e) {
            }
        }
        return "";
    }

    /**
     * http post请求
     *
     * @param url
     *            请求地址
     * @param params
     *            请求参数
     * @return
     */
    public static String post(String url, String params) {
        CloseableHttpResponse response = null;
        CloseableHttpClient httpClient = null;
        try {
            HttpPost httpPost = new HttpPost(url);
            StringEntity sEntity = new StringEntity(params, "utf-8");
            httpPost.setEntity(sEntity);
            RequestConfig config = RequestConfig.custom().setConnectionRequestTimeout(10000).setConnectTimeout(10000)
                    .setSocketTimeout(10000).build();
            httpPost.setConfig(config);
            httpClient = HttpClients.createDefault();
            response = httpClient.execute(httpPost);
            HttpEntity entity = response.getEntity();
            if (entity != null) {
                return EntityUtils.toString(entity, "utf-8");
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            try {
                response.close();
                httpClient.close();
            } catch (IOException e) {
            }
        }
        return "";
    }
}
