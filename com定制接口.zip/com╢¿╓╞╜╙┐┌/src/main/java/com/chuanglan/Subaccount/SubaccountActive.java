package com.chuanglan.Subaccount;

import com.chuanglan.Util.HttpUtil;

import java.util.HashMap;
import java.util.Map;

/*子账号激活：采用post方式提交请求*/
public class SubaccountActive {

    public static void main(String[] args) {
        /*请求地址*/
        String url="https://zz.253.com/apis/subaccount/active";

        Map<String, Object> map = new HashMap();
        /*必填参数*/
        map.put("appid","49");//需要设置的产品id（appid）
        map.put("account_id","");//子账号添加之后返回的id，在其他接口中写作sub_id

        String result = HttpUtil.post(url, map);
        System.out.println("响应参数 ："+result);

    }

}
