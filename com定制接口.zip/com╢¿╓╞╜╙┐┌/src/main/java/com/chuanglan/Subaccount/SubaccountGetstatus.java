package com.chuanglan.Subaccount;

import com.chuanglan.Util.HttpUtil;

import java.util.HashMap;
import java.util.Map;

/*子账号状态查询：采用post方式提交请求*/
public class SubaccountGetstatus {

    public static void main(String[] args) {
        /*请求地址*/
        String url="https://zz.253.com/apis/subaccount/getstatus";

        Map<String, Object> map = new HashMap();
        /*必填参数*/
        map.put("sub_id","");//子账号添加之后返回的id

        String result = HttpUtil.post(url, map);
        System.out.println("响应参数 ："+result);

    }

}
