package com.chuanglan.Subaccount;

import com.chuanglan.Util.HttpUtil;

import java.util.HashMap;
import java.util.Map;

/*子账号account_id查询：采用post方式提交请求*/
public class SubaccountGetids {

    public static void main(String[] args) {
        /*请求地址*/
        String url="https://zz.253.com/apis/subaccount/getids";

        Map<String, Object> map = new HashMap();
        /*必填参数username timestamp  signature    Public 中已经传递 */

        String result = HttpUtil.post(url, map);
        System.out.println("响应参数 ："+result);

    }

}
