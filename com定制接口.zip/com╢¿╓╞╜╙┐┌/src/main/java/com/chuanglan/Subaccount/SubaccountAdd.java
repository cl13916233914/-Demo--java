package com.chuanglan.Subaccount;

import com.chuanglan.Util.HttpUtil;

import java.util.HashMap;
import java.util.Map;

/*子账号添加：采用post方式提交请求*/
public class SubaccountAdd {

    public static void main(String[] args) {
        /*请求地址*/
        String url="https://zz.253.com/apis/subaccount/add";

        Map<String, Object> map = new HashMap();
        /*必填参数*/
        map.put("product_permit_pay","49:1");//需要设置子账号的扣款类型，格式为 产品id:扣款类型，比如 49:1 代表行业验证码主帐号计费，49:0代表示子账号独立计费
        map.put("use_type", "0"); //用途分类 如：0其它,1web，2app
        map.put("use_desc", "测试");//子账号用途（1-50字符）
        map.put("name","梅成浩");//姓名（<50字符）
        map.put("department","CRD运维");//部门或分部名称（<=8个字）
        map.put("position","专员");//职位（<=8个字）
        map.put("account_username","meichenghao2");//要开通的子账号名称（6-20字符）
        map.put("account_password","123456");//要开通的子账号密码（6-16字符）

        String result = HttpUtil.post(url, map);
        System.out.println("响应参数 ："+result);

    }
/* 成功案例 ： 响应参数 ：{"status":"success","data":{"id":"123163"}}  */
}
