package com.chuanglan.分类接口;

import com.chuanglan.Util.HttpUtil;

import java.util.HashMap;
import java.util.Map;

/*短信记录-->发送列表：采用post方式提交请求*/
public class SendrecordList {

    public static void main(String[] args) throws Exception {
        /*请求地址*/
        String url="https://zz.253.com/apis/sendrecord/list";

        Map<String, Object> map = new HashMap();
        /*必填参数*/
        map.put("appid", 49);//需要设置的产品id（appid）

        /*选填参数*/
        map.put("sub_id","");//子账号id
        map.put("start_date", "");//格式：xxxx-xx-xx，默认当天
        map.put("end_date","");//格式：xxxx-xx-xx，默认当天
        map.put("start","");//偏移量，默认为0
        map.put("length","");//查询的长度，默认为10，最大值为100天
        map.put("mobile","");//手机号码
        map.put("month_seq","");//批次记录
        map.put("status","");//DELIVRD查询成功，FAIL查询失败，UNKNOWN查询未知（不传则查询所有）

        String result = HttpUtil.post(url, map);
        System.out.println("响应参数 ："+result);
    }

}
