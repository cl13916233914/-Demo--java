package com.chuanglan.分类接口;

import com.chuanglan.Util.HttpUtil;

import java.util.HashMap;
import java.util.Map;

/*充值记录查询：采用post方式提交请求*/
public class QueryBalanceLog {

    public static void main(String[] args) throws Exception {
        /*请求地址*/
        String url="https://zz.253.com/apis/balance/queryBalanceLog";

        Map<String, Object> map = new HashMap();
        /*必填参数*/
        map.put("appid", 49);//需要设置的产品id（appid）

        /*选填参数*/
        map.put("sub_id","");//子账号id
        map.put("beginDate","");//格式：Ymd 如20180315 默认当天
        map.put("endDate","");//格式：Ymd，如20180315默认当天
        map.put("pageNo","");//页数 默认 1
        map.put("pageSize","");//显示条数 默认15

        String result = HttpUtil.post(url, map);
        System.out.println("响应参数 ："+result);
    }

}
