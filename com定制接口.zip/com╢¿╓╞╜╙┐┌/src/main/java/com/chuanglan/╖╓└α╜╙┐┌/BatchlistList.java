package com.chuanglan.分类接口;

import com.chuanglan.Util.HttpUtil;

import java.util.HashMap;
import java.util.Map;

/*发送记录：采用post方式提交请求*/
public class BatchlistList {

    public static void main(String[] args) throws Exception {
        /*请求地址*/
        String url="https://zz.253.com/apis/batchlist/list";

        Map<String, Object> map = new HashMap();
        /*必填参数*/
        map.put("appid", 52);//需要设置的产品id（appid）

        /*选填参数*/
        map.put("sub_id","");//子账号id
        map.put("start_date", "");//格式：xxxx-xx-xx，默认当天
        map.put("end_date","");//格式：xxxx-xx-xx，默认当天
        map.put("start","");//偏移量，默认为0
        map.put("length","");//查询的长度，默认为10，最大值为100天
        map.put("month_seq","");//批次记录
        map.put("status","");//发送状态，1等待审核，2-等待发送，3-发送中，4-发送完毕，5-审核驳回，6-取消，默认全部

        String result = HttpUtil.post(url, map);
        System.out.println("响应参数 ："+result);
    }

}