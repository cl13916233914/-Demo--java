package com.chuanglan.分类接口;

import com.chuanglan.Util.HttpUtil;

import java.util.HashMap;
import java.util.Map;

/*发送失败记录：采用post方式提交请求*/
public class SendError {

    public static void main(String[] args) {
        /*请求地址*/
        String url="https://zz.253.com/apis/errorStatistics/sendError";

        Map<String, Object> map = new HashMap();
        /*必填参数*/
        map.put("appid","49");//需要设置的产品id，由创蓝提供
        /*选填参数*/
        map.put("sub_id","");//子账号id
        map.put("start_date","");//格式：xxxx-xx-xx，默认当天
        map.put("end_date","");//格式：xxxx-xx-xx，默认当天

        String result = HttpUtil.post(url, map);
        System.out.println("响应参数 ："+result);
    }

}
